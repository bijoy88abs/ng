import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tasktable'
})
export class TasktablePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!args.taskName && !args.parentName && (!args.priorityFrom && !args.priorityTo) && (!args.startDate && !args.endDate)) { return value; }

    let returnList = value;
    if (args.taskName) {
      returnList = this.filterTaskName(returnList, args.taskName);
    }
    if (args.parentName) {
      returnList = this.filterParentName(returnList, args.parentName.toLower());
    }
    if (args.priorityFrom && args.priorityTo) {
      returnList = this.filterPriority(returnList, parseInt(args.priorityFrom), parseInt(args.priorityTo));
    }
    if (args.startDate && args.endDate) {
      returnList = this.filterDate(returnList, args.startDate, args.endDate);
    }
    return returnList;
  }


  filterTaskName(value, taskName) {
    const filteredArrayList = [];
    value.filter((obj) => {
      if (obj.taskName.toLowerCase().indexOf(taskName.toLowerCase()) === 0 && taskName) {
        filteredArrayList.push(obj);
      }
    });
    return filteredArrayList;
  }

  filterParentName(value, parentName) {
    const filteredArrayList = [];
    value.filter((obj) => {
      if (obj.taskName.toLowerCase().indexOf(parentName.toLowerCase()) === 0 && parentName) {
        filteredArrayList.push(obj);
      }
    });
    return filteredArrayList;
  }

  filterPriority(value, priorityFrom, priorityTo) {
    const filteredArrayList = [];
    value.filter((obj) => {
      if ((obj.priority >= priorityFrom) && (obj.priority <= priorityTo)) {
        filteredArrayList.push(obj);
      }
    });
    return filteredArrayList;
  }

  filterDate(value, startDate, endDate) {
    const filteredArrayList = [];
    value.filter((obj) => {
      if ((startDate <= obj.startDate) && (obj.endDate <= endDate)) {
        filteredArrayList.push(obj);
      }
    });
    return filteredArrayList;
  }

}
