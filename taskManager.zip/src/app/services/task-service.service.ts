import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService {

  uri = 'http://localhost:3000';
  constructor(private http: HttpClient) { }

  getTasks() {
    return this.http.get(`${this.uri}/api/tasks`);
  }

  postTask(jsonData) {
    return this.http.post(`${this.uri}/api/task`, jsonData);
  }

}
