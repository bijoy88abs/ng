import { Component, OnInit } from '@angular/core';
import { TaskServiceService } from '../../services/task-service.service';

@Component({
  selector: 'app-list-task',
  templateUrl: './list-task.component.html',
  styleUrls: ['./list-task.component.sass']
})
export class ListTaskComponent implements OnInit {

  public listTask: any;

  constructor(private taskService: TaskServiceService) { }

  ngOnInit() {
    this.taskService.getTasks().subscribe((response) => {
      this.listTask = response;
    });
  }

  deleteTask(): void {
    
  }

}
