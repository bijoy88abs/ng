import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms'
import { AbstractClassPart } from '@angular/compiler/src/output/output_ast';
import { TaskServiceService } from '../../services/task-service.service';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.sass']
})
export class CreateTaskComponent implements OnInit {

  createTaskForm: FormGroup;

  validationMessages = {
    'taskName': {
      'required': 'Task Name is Required'
    },
    'priority': {
      'required': 'Priority is Required'
    },
    'parentName': {
      'required': 'Parent Name is Required'
    },
    'startDate': {
      'required': 'Start Date is Required'
    },
    'endDate': {
      'required': 'End Date is Required'
    }
  };

  formErrors = {
    'taskName': '',
    'priority': '',
    'parentName': '',
    'startDate': '',
    'endDate': ''
  };

  constructor(private fb: FormBuilder, private taskService: TaskServiceService) { }

  ngOnInit() {
    this.createTaskForm = this.fb.group({
      taskName: ['', Validators.required],
      priority: ['', Validators.required],
      parentName: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required]
    });

    this.createTaskForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.createTaskForm);
    });

  }

  logValidationErrors(group: FormGroup = this.createTaskForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const getKeyInfo = group.get(key);
      if (getKeyInfo && !getKeyInfo.valid && (getKeyInfo.touched || getKeyInfo.dirty)) {
        const messages = this.validationMessages[key];
        for (const errorKey in getKeyInfo.errors) {
          if (errorKey) {
            this.formErrors[key] = messages[errorKey];
          }
        }
      } else {
        this.formErrors[key] = '';
      }
    });
  }

  onSubmitForm(group: FormGroup = this.createTaskForm): void {
    if (!this.createTaskForm.valid) {
      this.logValidationErrors(this.createTaskForm);
      return;
    }
    let jsondata = {};
    Object.keys(group.controls).forEach((key: string) => {
      jsondata[key] = group.get(key).value;
    });
    this.taskService.postTask(jsondata).subscribe(() => {
      this.createTaskForm.reset();
    });
  }

}
