import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListTaskComponent } from './components/list-task/list-task.component';
import { CreateTaskComponent } from './components/create-task/create-task.component';
import { EditTaskComponent } from './components/edit-task/edit-task.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TaskServiceService } from 'src/app/services/task-service.service';

@NgModule({
  declarations: [
    AppComponent,
    ListTaskComponent,
    CreateTaskComponent,
    EditTaskComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    TaskServiceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
