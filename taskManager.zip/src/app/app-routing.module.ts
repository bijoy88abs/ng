import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListTaskComponent } from 'src/app/components/list-task/list-task.component';
import { CreateTaskComponent } from 'src/app/components/create-task/create-task.component';
import { EditTaskComponent } from 'src/app/components/edit-task/edit-task.component';

const routes: Routes = [
  { path: 'list', component: ListTaskComponent },
  { path: 'create', component: CreateTaskComponent },
  { path: 'edit/:id', component: EditTaskComponent },
  { path: '', redirectTo: 'list', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
