const express = require("express");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

const tasks = [];

app.get('/', (req, res) => {
    res.send('Server works!');
});

app.get('/api/tasks', (req, res) => {
    res.send(tasks);
});

app.get('/api/tasks/:id', (req, res) => {
    const task = tasks.find(c => c.id === parseInt(req.params.id));
    if (!task) res.status(404).send('task not found');
    res.send(task);
});

app.post('/api/task', (req, res) => {    
    const task = {
        id: tasks.length+1,
        taskName: req.body.taskName,
        priority: req.body.priority,
        parentName: req.body.parentName,
        startDate: req.body.startDate,
        endDate: req.body.endDate
    }
    tasks.push(task);
    res.send(task);
});


app.listen(3000, () => console.log('server is running on 3000 port'));